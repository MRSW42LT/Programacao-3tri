/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoas;

/**
 *
 * @author pc
 */
public class Principal {
    public static void main(String[] args) {
        
        Pessoas pessoa1 = new Pessoas("Denis",12, 1.50);
        pessoa1.impirimirDados();
    
    }
    
}
