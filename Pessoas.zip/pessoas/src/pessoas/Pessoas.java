/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoas;

/**
 *
 * @author pc
 */
public class Pessoas {
    public Pessoas (String nome,int idade,double altura){
        setNome(nome);
        setIdade(idade);
        setAltura(altura);
    }
    public void impirimirDados(){
        System.out.println("Nome "+getNome() );
        System.out.println("idade "+getIdade());
        System.out.println("altura "+getAltura());
        
    }
    
    private String nome;
    private int idade;
    private double altura;
    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the idade
     */
    public int getIdade() {
        return idade;
    }

    /**
     * @param idade the idade to set
     */
    public void setIdade(int idade) {
        this.idade = idade;
    }

    /**
     * @return the altura
     */
    public double getAltura() {
        return altura;
    }

    /**
     * @param altura the altura to set
     */
    public void setAltura(double altura) {
        this.altura = altura;
    }
    
}